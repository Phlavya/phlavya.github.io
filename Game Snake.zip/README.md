A cobrinha precisa comer e você precisa ser rápido!
  